---
title: 对 shortlink再做一下测试
date: 2022-05-06 18:58:12
excerpt: 为啥要做？做完后有何收获感想体会？
tags: 
rating: ⭐
status: complete
destination: 03-98
share: false
obsidianUIMode: source
---

感觉没啥问题啊！