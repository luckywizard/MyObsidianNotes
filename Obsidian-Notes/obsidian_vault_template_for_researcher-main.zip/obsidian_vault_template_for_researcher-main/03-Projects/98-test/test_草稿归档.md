---
title: test_草稿归档
date: 2022-05-05 10:49:04
excerpt: 为啥要做？做完后有何收获感想体会？
tags: 
rating: ⭐
status: complete
destination: 03-98
share: false
obsidianUIMode: source
---

没啥问题啊，注意 destination 是一定要填写的，至于 tags 为空问题不大。此命令依赖于 python 脚本，如果 python 环境不对（常见于 macOS），也是不会有反应的。