---
title: obsidian快捷键
date: 2022-03-29 13:39:48
excerpt: 掌握常用的快捷键事半功倍。
tags: obsidian附录
rating: ⭐
status: complete
destination: 03-Projects/黑曜石玩家指南
share: false
---

![[Pasted image 20220329134340.png]]

在 obsidian 中查询和自定义快捷键非常方便。有了快捷键，能够提高一些我们日常操作的效率。下方列举了我常用的快捷键：

- `Ctrl+E`：页面预览
- `Ctrl+Shift+E`：幻灯片预览
- `Ctrl+Alt+M`：思维导图预览
- `Ctrl+Q`：quickAdd命令面板
- `Alt+E`：Templater插入模板面板
- `Ctrl+L`：锁定页面
- `Ctrl+Alt+2`：对选定文字背景橙色高亮
- `Ctrl+K`：对选定文字插入超链接
- `Ctrl+H`：寻找并替换文字
- `Ctrl+/`：注释掉选中的文字
- `Ctrl+Enter`：创建或完成TODO清单
- `Alt+T`：跳转到今日日志页面
- `Ctrl+0` ：将编辑器的实时预览切换为纯文本编辑模式

---

page:: 26