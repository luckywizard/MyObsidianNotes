<!--此页面存放原始按钮-->

```button
name ⏱track
type command
action QuickAdd: ⏱️随手记记
class grad_button g_yellow
```
^button-ssjj

```button
name 🐮task
type command
action QuickAdd: 🐮新增任务
class grad_button g_green
```
^button-xzrw

```button
name 📒草稿归档
type command
action Shell commands: Execute: test_草稿归档
class grad_button g_lightgreen
```
^button-cggd
